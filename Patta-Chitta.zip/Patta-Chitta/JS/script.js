const districtselect = document.querySelector('#district');
const talukselect = document.querySelector('#taluk');
const villageselect = document.querySelector('#village');

const datas = {
    'Ariyalur' : {
        'Andimadam' : ['Athukurichi', 'Koovathur', 'Maruthur'], 
        'Sendurai' : ['Kuzhumur', 'Nakkampadi', 'Paranam'], 
        'Udayarpalayam' : ['Edayar', 'Kadambur', 'Sathampadi']
    }, 
    'Chengalpattu' : {
        'Pallavaram' : ['Anagaputhur', 'Pozhichalur', 'Thirusulam'], 
        'Tambaram' : ['Chitlapakkam', 'Medavakkam', 'Mudichur'], 
        'Vandalur' : ['Guduvancheri', 'Kolatur', 'Manivakkam']
    }, 
    'Chennai' : {
        'Alandur' : ['Manapakkam', 'Meenambakkam', 'Nanthambakkam'], 
        'Maduravayol' : ['Karambakkam', 'Porur', 'Valasaravakkam'], 
        'Sholinganallur' : ['Enchambakkam', 'Madipakkam', 'Seevaram']
    }
}

function populateselect(selectelement, options) {
    selectelement.innerHTML = '<option value=""> Select ' + selectelement.name + '</option>';
    for (const option of options) {
        const optionelement = document.createElement('option');
        optionelement.value = option;
        optionelement.textContent = option;
        selectelement.appendChild(optionelement);
    }
}

districtselect.addEventListener('change', () => {
    const selecteddistrict = districtselect.value;
    const taluks = Object.keys(datas[selecteddistrict]);
    populateselect(talukselect, taluks);
});

talukselect.addEventListener('change', () => {
    const selecteddistrict = districtselect.value;
    const selectedtaluk = talukselect.value;
    const villages= datas[selecteddistrict][selectedtaluk];
    populateselect(villageselect, villages);
});

villageselect.addEventListener('change', () => {
    const selecteddistrict = districtselect.value;
    const selectedtaluk = talukselect.value;
    const selectedvillage = villageselect.value; 
});

districtselect.dispatchEvent(new Event('change'));